<?php

return [
    'adminEmail' => 'jiitendra.yadav@gmail.com',
    'settings'=>[
        'copyright'=>'ikodes technology',
        'websitename'=>'iT - Customer Management System',
        'email'=>'ikodes.technology@gmail.com'
    ],
];
